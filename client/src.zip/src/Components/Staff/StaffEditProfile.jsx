import React from 'react'

function StaffEditProfile() {
  return (
    <div>StaffEditProfile</div>
  )
}

export default StaffEditProfile