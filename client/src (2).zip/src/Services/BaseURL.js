

// export const IMG_BASE_URL = 'http://localhost:4049/';
// export const API_BASE_URL = 'http://localhost:4049/theatre_api';

export const IMG_BASE_URL = 'https://hybrid.srishticampus.in/';
export const API_BASE_URL = 'https://hybrid.srishticampus.in/theatre_api';



