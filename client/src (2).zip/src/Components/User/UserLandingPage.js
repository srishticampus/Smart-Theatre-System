import React from 'react'

function UserLandingPage() {
  return (
    <div>
      
    </div>
  )
}

export default UserLandingPage
